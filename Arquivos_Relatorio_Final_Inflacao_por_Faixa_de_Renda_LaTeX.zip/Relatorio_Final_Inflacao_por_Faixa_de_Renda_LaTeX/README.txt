Relatório final em LaTeX

Ficheiro principal:
Relatorio_Final_Inflacao_por_Faixa_de_Renda.tex

As figuras figura_gap.png e figura_residuos.png devem permanecer na mesma pasta do ficheiro .tex.

Compilação local:
tectonic Relatorio_Final_Inflacao_por_Faixa_de_Renda.tex

ou, com uma distribuição LaTeX tradicional:
pdflatex Relatorio_Final_Inflacao_por_Faixa_de_Renda.tex
pdflatex Relatorio_Final_Inflacao_por_Faixa_de_Renda.tex

A compilação online pode ser feita no Overleaf carregando o ficheiro .tex e as duas imagens.
